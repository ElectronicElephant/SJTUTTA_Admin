# GDEW0154Z04 1.54" dual-color e-paper library for Arduino
GDEW0154Z04 1.54" dual-color e-paper library for Arduino
## Hardware connection (e-Paper --> Arduino)
    3.3V --> 3V3
    GND  --> GND
    DIN  --> D11
    CLK  --> D13
    CS   --> D10
    DC   --> D9
    RST  --> D8
    BUSY --> D7
## Expected result
1.  Copy the libraries file of Arduino demo code to the libraries folder 
    (C:\users\username\documents\arduino\libraries by default. You can also 
    specify the location on 
    Arduino IDE --> File --> Preferences --> Sketchbook location).
2.  File > Examples > epd1in54b > epd1in54b-demo
3.  Upload the project.
4.  The e-Paper will display images.

