# GDEM0213E26LT 2.13" e-paper library for Arduino
GDEM0213E26LT 2.13" e-paper library for Arduino
## Hardware connection (e-Paper --> Arduino)
    3.3V --> 3V3
    GND  --> GND
    DIN  --> D11
    CLK  --> D13
    CS   --> D10
    DC   --> D9
    RST  --> D8
    BUSY --> D7
## Expected result
1.  Copy the libraries file of Arduino demo code to the libraries folder 
    (C:\users\username\documents\arduino\libraries by default. You can also 
    specify the location on 
    Arduino IDE --> File --> Preferences --> Sketchbook location).
2.  File > Examples > epd2in13 > epd2in13-demo
3.  Upload the project.
4.  The e-Paper will display images.

