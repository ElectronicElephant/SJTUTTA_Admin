﻿# e-Paper  
waveshare electronics
![waveshare_logo.png](waveshare_logo.png)

## 中文:  
Jetson Nano、Raspberry Pi、Arduino、STM32例程
* Raspberry Pi & Jetson Nano:  
    > C
    > Python 
* Arduino:  
    > Arduino UNO  
* STM32:  
    > STM32F103ZET6 
    
更多资料请在官网上搜索:  
http://www.waveshare.net


## English:  
Jetson Nano、Raspberry Pi、Arduino、STM32 Demo:  
* Raspberry Pi & Jetson Nano:  
    > C
    > Python
* Arduino:  
    > Arduino UNO  
* STM32:  
    > STM32F103ZET6 
    
For more information, please search on the official website:   
https://www.waveshare.com



